package Practical01;

public class Task1 {
	public static void main(String[] args) {
//		System.out.println("This is my first attempt to");
//		System.out.println("program in Java");
//		System.out.println("It works!");

		System.out.print("This is");
		System.out.println("my first attempt");
		System.out.println("to program");
		System.out.println("in Java");
		System.out.println("\tIt works!");
	}
}
